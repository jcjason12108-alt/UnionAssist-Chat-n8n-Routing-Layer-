=== n8n ChatAgent for Unions ===
Contributors: Jason Cox
Tags: chat, ai, live-chat, customer-support, webhook
Requires at least: 5.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI-powered chat widget purpose-built for labor organizations that run n8n. Messages are relayed only to the webhook URL you configure, keeping control of data in your own automation stack.

== Description ==

n8n ChatAgent for Unions drops a single floating chat window onto any WordPress site and immediately hands conversations off to an n8n webhook. There is no bundled AI brain, no SaaS dependency, and no example workflow hiding in the plugin—every message is proxied to the endpoint you configure, and whatever JSON that endpoint returns is what the visitor sees.

The defaults (copy, gradients, disclaimers, icon handling) are tuned for labor and organizing teams but can be customized entirely from wp-admin. Because the plugin is just a UI shell, you keep control of storage, routing, compliance, and safety enforcement inside your n8n flows.

Important compatibility note: this plugin is **only tested with n8n webhooks**. Other automation services (Zapier, Make, Pipedream, custom APIs, etc.) might respond correctly, but they are unverified. Test thoroughly before exposing anything except n8n to production traffic.

== Features ==

* **Webhook-first chat:** Every message is proxied to the webhook you choose (HTTPS enforced). Whatever JSON your n8n workflow returns is rendered back in the widget—no bundled AI service or SaaS dependency.
* **Union-aware metadata:** Logged-in members automatically contribute ID, display name, email, role(s), username, IAM local identifier, and an HMAC-signed session token. Guest visitors still send anonymous session IDs plus device/locale info so you can branch flows.
* **Attachment uploads (mode-controlled):** PDF/JPG/PNG uploads are always available but you decide how the button behaves (Never / Always / Agent-controlled). Drop the phrase `[ATTACHMENT_READY]` (or any custom keyword you configure) into your workflow reply to surface the uploader exactly when the agent asks for files.
* **Custom greetings & disclaimers:** Turn the welcome webhook call off, inject your own greeting text, and define multi-line disclaimers. The header subtitle accepts links and shortcodes so you can surface policy, office hours, or live status indicators.
* **Brandable launcher & bot identity:** Upload launcher or bot avatars, pick one of the baked-in SVG icons, adjust widget width/height, and control the full IAM color palette (primary, gradient, bubble colors, etc.).
* **Quick actions & human handoff:** Configure quick-action chips that send canned questions, expose a “request a human” CTA when live agents are online, and reset chats cleanly between sessions.
* **Persistent transcripts:** Conversations are cached in the browser’s localStorage so a user can navigate between pages without losing context. Logging out or using “Start New Chat” wipes the cache instantly.
* **Full-screen mobile experience:** On phones the widget expands to a safe-area aware overlay with scroll locking so the input is always accessible. Desktop keeps the floating launcher with gradient header.
* **Security hardened:** AJAX endpoints use nonces/cap checks, webhook URLs must be HTTPS, attachments are sanitized server-side, and user tokens expire based on the TTL you set. There is zero “pro edition” or third-party tracking baked in.

== Bug Fix Highlights ==

* Fixed attachment uploads so they only appear when enabled, sanitize before forwarding, and visually confirm when they’re sent.
* Hardened the launcher so optional UI (icons, quick actions, disclaimers) no longer block the chat from opening.
* Added transcript caching that survives page navigation yet clears automatically when members log out or click “Start New Chat”.
* Resolved double-encoding on admin textareas (subtitle/disclaimer) so HTML links stay intact no matter how many times you save.

== Security & Privacy Review ==

* Visitor text is POSTed to a WordPress AJAX endpoint which relays it to your webhook; authenticate/authorize that WordPress origin and continue sanitizing any HTML you echo back (the widget only does minimal markdown formatting).
* A single optional request to `http://ip-api.com` is used for coarse IP geolocation; replace or disable that call if HTTP lookups violate your policies.
* The plugin never stores user credentials. Persisting transcripts, retention rules, and audit logging are entirely up to your n8n workflows; only a short-term transcript cache lives in the visitor’s browser to keep sessions consistent.
* REST/AJAX endpoints require WordPress nonces/capabilities so anonymous visitors can only hit the endpoints intended for them.
* The JavaScript bundle stays in a closure and now guards optional DOM nodes, preventing runtime crashes that previously stopped replies from rendering.

== Installation ==

1. Upload `n8n-chatagent-for-unions` to `/wp-content/plugins/` (if zipping manually, compress that folder itself—WordPress will reject double-wrapped archives like `New AI Live Chat Test.zip`).
2. Activate via **Plugins → Installed Plugins**.
3. Visit **n8n ChatAgent for Unions** under the admin menu and enter your n8n webhook URL plus any optional copy/branding tweaks.
4. Load the frontend— the widget attaches itself to `<body>` automatically.

== Frequently Asked Questions ==

= Does it work without n8n? =
Only n8n webhooks have been tested. Other REST endpoints may work, but you are responsible for validating payload formats and responses.

= Where are conversations stored? =
Nowhere inside WordPress. Every message is forwarded to your webhook; store transcripts inside your automation (e.g., n8n workflows writing to databases, CRMs, etc.).

= Can I change the look and feel? =
Yes. All primary colors, iconography, greeting copy, and disclaimers are editable from the settings page. For deeper layout changes, edit `assets/chat-widget.css`.

= Can visitors upload attachments? =
Yes. Attachments are always enabled behind the scenes. Use the **Attachment Button Mode** setting to hide the UI (Never), show it permanently (Always), or let your workflow control it (Agent-controlled). In agent mode include your configured keyword (defaults to `[ATTACHMENT_READY]`) somewhere in your workflow reply when you want the uploader button to appear; otherwise it stays hidden. Files are converted to base64 (PDF/JPG/PNG by default) and forwarded to your webhook alongside the message.

= Does it support user authentication? =
The plugin passes WordPress user context (role, name, email, token) to your webhook when someone is logged in. You decide how to use that metadata inside your automation.

= Does the chat leave data on a shared computer? =
For continuity the widget stores the transcript in the browser’s localStorage until the user logs out or clicks “Start New Chat”. Remind members not to leave sensitive chats open on shared devices, and note this behavior in your privacy policy if needed.

== Changelog ==

= 1.0.2 =
* Bumped the plugin version to flush caches and ensure the new attachment-mode logic ships everywhere.
* Hardened attachment rendering so the paperclip is present whenever attachments are enabled, regardless of how WordPress serializes the setting.
* Removed the redundant “Allow Attachments” checkbox—use the Attachment Button Mode (Never/Always/Agent) instead, with `[ATTACHMENT_READY]` as the workflow trigger.

= 1.0.1 =
* Added attachment visibility modes (Never/Always/Agent) plus the `[ATTACHMENT_READY]` trigger phrase so workflows can request uploads dynamically.
* Made the attachment trigger keyword configurable from the settings page so you can match whatever phrase your workflow already emits.
* Added a “Default Agent Identifier” setting so every payload includes a consistent `agentId` for n8n routing (falls back to a slug of the assistant name if blank).
* Fixed disclaimer link helpers double-encoding/duplicating anchors when saving settings repeatedly.
* Ensured helper link fields and sanitizers work together so subtitles/disclaimers stay human-readable.

= 1.0.0 =
* Added attachment uploads (with admin-side toggles/limits) plus visual chips inside the transcript so visitors know files were sent.
* Enabled shortcode/HTML support inside the header subtitle and surfaced clickable IAM-styled links.
* Forwarded richer metadata to n8n (union tokens, visitor device info, optional geolocation, session timing) and exposed token TTL controls.
* Enforced a true full-screen mobile layout (with scroll locking) so chats fill the viewport on phones.
* Removed the deprecated "disclaimer secondary text" option so the streamlined disclaimer controls the entire footer.
* Hardened the JavaScript bootstrap, guarding optional buttons and keeping the first agent reply visible (fixes the "No agent has populated" symptom).
* Added a WordPress-side webhook proxy so CORS is no longer required and your webhook URL stays out of the browser.
* Cached transcripts in localStorage so conversations survive page changes, while automatically clearing them on logout or manual resets.
* Reworked the readme/security notes to make the GitHub distribution, n8n-only support, and packaging instructions explicit.
